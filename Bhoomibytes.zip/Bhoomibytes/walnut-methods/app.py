"""
app.py
------
Flask + MongoDB backend for the BhoomiBytes land governance project.

Responsibilities:
  * Serve the existing HTML pages and static assets.
  * Connect to a local MongoDB instance (configurable via environment).
  * Seed the demo data into MongoDB on first run.
  * Expose read-only JSON APIs for lands and their related policies.

Configuration (environment variables, all optional):
  MONGO_URI  -> default "mongodb://127.0.0.1:27017"
  MONGO_DB   -> default "bhoomibytes"

Run with:  python app.py
Then open: http://127.0.0.1:5000
"""

import os
import sys

from flask import Flask, abort, jsonify, send_from_directory
from pymongo import MongoClient

from seed_data import LANDS, POLICIES

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MONGO_URI = os.environ.get("MONGO_URI", "mongodb://127.0.0.1:27017")
MONGO_DB = os.environ.get("MONGO_DB", "bhoomibytes")
COLL_LANDS = "lands"
COLL_POLICIES = "policies"

app = Flask(__name__)

# File types we are willing to serve from the project root.
# This deliberately excludes .py so source stays private.
ALLOWED_EXTENSIONS = {
    ".html", ".css", ".js", ".json", ".geojson",
    ".png", ".jpg", ".jpeg", ".svg", ".ico",
}

# MongoClient is lazy: no connection is made until the first operation.
client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)
db = client[MONGO_DB]
lands_coll = db[COLL_LANDS]
policies_coll = db[COLL_POLICIES]


# ------------------------------------------------------------------ #
# Database helpers                                                    #
# ------------------------------------------------------------------ #
def check_mongo():
    """Ping the database. Returns True when reachable, prints a hint otherwise."""
    try:
        client.admin.command("ping")
        return True
    except Exception as exc:
        print("Could not connect to MongoDB at", MONGO_URI)
        print("Is 'mongod' running? Error:", exc)
        return False


def init_db():
    """Create indexes and load demo data on first run."""
    lands_coll.create_index("survey", unique=True)
    policies_coll.create_index("survey")

    if lands_coll.count_documents({}) == 0:
        lands_coll.insert_many(LANDS)

    if policies_coll.count_documents({}) == 0:
        policies_coll.insert_many(POLICIES)


# ------------------------------------------------------------------ #
# API routes (read-only)                                              #
# ------------------------------------------------------------------ #
@app.route("/api/health", methods=["GET"])
def health():
    db_ok = check_mongo()
    return jsonify({
        "status": "ok" if db_ok else "degraded",
        "app": "BhoomiBytes",
        "version": "1.0.0",
        "database": MONGO_DB,
    })


@app.route("/api/lands", methods=["GET"])
def list_lands():
    docs = list(lands_coll.find({}, {"_id": 0}))
    # Sort numerically by survey number (surveys are stored as strings)
    docs.sort(key=lambda d: int(d.get("survey") or 0))
    return jsonify(docs)


@app.route("/api/lands/<survey>", methods=["GET"])
def get_land(survey):
    doc = lands_coll.find_one({"survey": survey}, {"_id": 0})
    if doc is None:
        return jsonify({"error": "Land not found"}), 404
    return jsonify(doc)


@app.route("/api/lands/<survey>/policies", methods=["GET"])
def get_land_policies(survey):
    if lands_coll.find_one({"survey": survey}, {"_id": 0, "survey": 1}) is None:
        return jsonify({"error": "Land not found"}), 404

    docs = list(policies_coll.find({"survey": survey}).sort("_id", 1))
    for doc in docs:
        doc.pop("_id", None)
    return jsonify(docs)


@app.route("/api/policies", methods=["GET"])
def list_all_policies():
    docs = list(policies_coll.find({}).sort("_id", 1))
    for doc in docs:
        doc.pop("_id", None)
    return jsonify(docs)


# ------------------------------------------------------------------ #
# Static HTML / asset serving                                         #
# ------------------------------------------------------------------ #
@app.route("/")
def index():
    return send_from_directory(BASE_DIR, "indexx1.html")


@app.route("/<path:filename>")
def static_files(filename):
    ext = os.path.splitext(filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS or ".." in filename:
        abort(404)

    # Guard against path traversal outside the project root.
    full_path = os.path.realpath(os.path.join(BASE_DIR, filename))
    if not full_path.startswith(os.path.realpath(BASE_DIR)):
        abort(404)

    return send_from_directory(BASE_DIR, filename)


# ------------------------------------------------------------------ #
if __name__ == "__main__":
    if not check_mongo():
        sys.exit(1)
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=True)
