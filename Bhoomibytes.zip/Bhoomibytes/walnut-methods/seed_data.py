"""
seed_data.py
------------
Demo land and policy records for the BhoomiBytes backend.

These mirror the data that was previously hardcoded in the HTML files
(indexx1.html / intexx.html for lands, policies.html for policies).
The Flask app imports this module and inserts the records into SQLite
the first time it runs.
"""

LANDS = [
    {
        "survey": "101",
        "owner": "Government of Karnataka",
        "district": "Bengaluru Rural",
        "taluk": "Devanahalli",
        "village": "Harohalli",
        "area": "3 Acres 25 Guntas",
        "date": "14-08-2021",
        "land_type": "Government",
        "lat": 13.2425,
        "lng": 77.7139,
        "neighbours": ["100", "102", "103", "110"],
    },
    {
        "survey": "205",
        "owner": "Ramesh Gowda",
        "district": "Mandya",
        "taluk": "Srirangapatna",
        "village": "Belagola",
        "area": "1 Acre 18 Guntas",
        "date": "03-01-2019",
        "land_type": "Private",
        "lat": 12.4220,
        "lng": 76.6930,
        "neighbours": ["204", "206", "207"],
    },
    {
        "survey": "310",
        "owner": "Revenue Department",
        "district": "Mysuru",
        "taluk": "Nanjangud",
        "village": "Hullahalli",
        "area": "5 Acres",
        "date": "22-11-2023",
        "land_type": "Government",
        "lat": 12.1180,
        "lng": 76.6820,
        "neighbours": ["309", "311", "312"],
    },
]

POLICIES = [
    # ---- Survey 101 ----
    {
        "survey": "101",
        "title": "Karnataka Land Revenue Act, 1964",
        "code": "Section 94",
        "description": "Every parcel of land must be surveyed, classified and recorded in the village accounts. This survey land is held by the Government under the RTC (Record of Rights, Tenancy and Crops) issued for Bengaluru Rural district.",
        "ministry": "Revenue Department",
        "valid_till": "31-03-2027",
        "status": "Active",
    },
    {
        "survey": "101",
        "title": "Karnataka Land Reforms Act, 1961",
        "code": "Section 63",
        "description": "Ceiling on holdings applies to agricultural land in Devanahalli Taluk. Government land classified under this survey cannot be held beyond the prescribed ceiling for private ownership.",
        "ministry": "Revenue Department",
        "valid_till": "31-03-2027",
        "status": "Active",
    },
    {
        "survey": "101",
        "title": "Bhoomi Digital Land Records Scheme",
        "code": "Bhoomi RTC 120",
        "description": "Under the National Digital Land Records Mission, the RTC for this survey number is maintained digitally and can be accessed through the Bhoomi portal for Bengaluru Rural district.",
        "ministry": "DPAR / e-Governance",
        "valid_till": "Ongoing",
        "status": "Active",
    },
    {
        "survey": "101",
        "title": "Karnataka Land Grant Rules, 1969",
        "code": "Rule 6",
        "description": "Government land grants for Survey No 101 are processed under the eligibility criteria laid down for landless beneficiaries in Bengaluru Rural district.",
        "ministry": "Revenue Department",
        "valid_till": "31-03-2027",
        "status": "Active",
    },

    # ---- Survey 205 ----
    {
        "survey": "205",
        "title": "Karnataka Land Reforms Act, 1961",
        "code": "Section 5",
        "description": "Private agricultural land held by Ramesh Gowda (Survey No 205, Belagola, Srirangapatna Taluk) is governed by tenancy and ownership provisions of the Act.",
        "ministry": "Revenue Department",
        "valid_till": "31-03-2027",
        "status": "Active",
    },
    {
        "survey": "205",
        "title": "Karnataka Land Revenue Act, 1964",
        "code": "Section 81",
        "description": "Mutation of records for this private land is mandatory within 30 days of any transfer so that the land records remain updated in the village account.",
        "ministry": "Revenue Department",
        "valid_till": "31-03-2027",
        "status": "Active",
    },
    {
        "survey": "205",
        "title": "Karnataka Conversion of Land (Prohibition) Rules",
        "code": "Conversion Order",
        "description": "Any conversion of this agricultural land (Survey No 205) for non-agricultural purposes requires prior permission from the Deputy Commissioner, Mandya.",
        "ministry": "Deputy Commissioner (Mandya)",
        "valid_till": "31-03-2027",
        "status": "Active",
    },
    {
        "survey": "205",
        "title": "Krishi Bhagya / Agriculture Support Scheme",
        "code": "Mandya Zone",
        "description": "Eligibility for agriculture support and subsidy schemes under the Mandya irrigation project is determined based on the land holding recorded for this survey number.",
        "ministry": "Agriculture Department",
        "valid_till": "31-03-2027",
        "status": "Active",
    },

    # ---- Survey 310 ----
    {
        "survey": "310",
        "title": "Karnataka Land Revenue Act, 1964",
        "code": "Section 74",
        "description": "Revenue Department land (Survey No 310, Hullahalli, Nanjangud Taluk) is accounted in the revenue register and is subject to periodic inspection by the Revenue Inspector.",
        "ministry": "Revenue Department",
        "valid_till": "31-03-2027",
        "status": "Active",
    },
    {
        "survey": "310",
        "title": "Karnataka Land Reforms Act, 1961",
        "code": "Section 79(A)",
        "description": "This Government land in Mysuru district is reserved and cannot be alienated to private parties without the prior sanction of the competent authority.",
        "ministry": "Revenue Department",
        "valid_till": "31-03-2027",
        "status": "Active",
    },
    {
        "survey": "310",
        "title": "National Land Records Modernisation Programme",
        "code": "NLRMP-ID",
        "description": "Survey No 310 is mapped under the National Land Records Modernisation Programme with digitised cadastral maps maintained for Nanjangud Taluk.",
        "ministry": "Central / State Land Records",
        "valid_till": "Ongoing",
        "status": "Active",
    },
    {
        "survey": "310",
        "title": "Karnataka Irrigation (Cauvery) Policy",
        "code": "Cauvery Zone",
        "description": "Land falling within the Cauvery irrigation zone (Hullahalli) is regulated for cropping patterns and water usage under the Mysuru Division irrigation policy.",
        "ministry": "Water Resources Department",
        "valid_till": "31-12-2026",
        "status": "Active",
    },
]
