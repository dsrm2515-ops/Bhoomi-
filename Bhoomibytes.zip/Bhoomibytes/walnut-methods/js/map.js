// Create the map
const map = L.map("map").setView([15.3173, 75.7139], 7);

// OpenStreetMap background
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "© OpenStreetMap"
}).addTo(map);

// Karnataka districts GeoJSON
fetch("data/karnataka_districts.geojson")
  .then(response => response.json())
  .then(data => {

    const districtLayer = L.geoJSON(data, {

      style: {
        color: "#2e7d32",
        weight: 1,
        fillColor: "#81c784",
        fillOpacity: 0.6
      },

      onEachFeature: (feature, layer) => {

        layer.bindTooltip(feature.properties.district);

        layer.on("click", () => {

          // Highlight selected district
          districtLayer.resetStyle();

          layer.setStyle({
            fillColor: "#ffca28",
            fillOpacity: 0.9,
            weight: 2
          });

          // Zoom into district
          map.fitBounds(layer.getBounds());

          // Load taluks later
          alert("District Selected: " + feature.properties.district);

        });

      }

    });

    districtLayer.addTo(map);

  })
  .catch(err => console.log(err));