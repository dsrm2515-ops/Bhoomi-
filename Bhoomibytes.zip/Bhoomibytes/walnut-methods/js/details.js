// js/details.js

function showDetails(land) {

    const details = document.getElementById("details");

    details.innerHTML = `
        <h2>Survey No. ${land.survey_no}</h2>

        <p><strong>Land Type:</strong> ${land.land_type}</p>

        <p><strong>Owner:</strong> ${land.owner}</p>

        <p><strong>Registration Date:</strong>
        ${land.day} ${land.month} ${land.year}</p>

        <p><strong>Area:</strong> ${land.guntas} Guntas</p>

        <hr>

        <h3>Neighbouring Lands</h3>

        <table>
            <tr>
                <th>Survey</th>
                <th>Owner</th>
                <th>Guntas</th>
            </tr>

            ${land.neighbours.map(n => `
                <tr>
                    <td>${n.survey}</td>
                    <td>${n.owner}</td>
                    <td>${n.guntas}</td>
                </tr>
            `).join("")}
        </table>
    `;
}


// Demo data (remove when backend is ready)

const demoLand = {
    survey_no: "145/2",
    land_type: "Government Land",
    owner: "Government of Karnataka",
    day: 12,
    month: "June",
    year: 2019,
    guntas: 18,

    neighbours: [
        {
            survey: "145/1",
            owner: "Ramesh Gowda",
            guntas: 12
        },
        {
            survey: "145/3",
            owner: "Govt School",
            guntas: 8
        },
        {
            survey: "146",
            owner: "Lakshmi Devi",
            guntas: 20
        }
    ]
};


// For testing only
setTimeout(() => {
    showDetails(demoLand);
}, 1000);